# Terraria Menu (nurz) — modul LSPatch

Target: Terraria 1.4.5.8.6 (com.and.games505.TerrariaPaid), Unity IL2CPP, tanpa root.

## Build
1. Upload folder ini ke repo GitHub baru.
2. Tab Actions -> "Build APK" -> Run workflow (atau otomatis saat push).
3. Unduh artifact `TerrariaMenu-debug` -> dapat `app-debug.apk` (modul).

## Pakai
1. Pasang `app-debug.apk` (modul).
2. Backup dunia/karakter dulu: Android/data/com.and.games505.TerrariaPaid/files
3. Di LSPatch Manager: Patch APK Terraria (mode embed/integrated), centang modul "Terraria Menu (nurz)".
4. Uninstall Terraria lama (tanda tangan berbeda), pasang hasil patch, kembalikan backup.
5. Buka game, masuk dunia, tap tombol "N" (bisa digeser).

## Kalau ada fitur gagal
Tap "Diagnostik" di menu, kirim hasilnya ke Claude. Log juga ada di logcat dengan tag NurzTerraria.
