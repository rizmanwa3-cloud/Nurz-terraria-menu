// Jembatan native: memanggil method Terraria (Unity IL2CPP) lewat API il2cpp_* yang
// di-export libil2cpp.so. Tidak memakai offset tetap, jadi tahan terhadap update versi.
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>

#define TAG "NurzTerraria"
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

namespace {

struct Api {
    void* (*domain_get)();
    void* (*thread_attach)(void*);
    void** (*domain_get_assemblies)(void*, size_t*);
    void* (*assembly_get_image)(void*);
    void* (*class_from_name)(void*, const char*, const char*);
    void* (*class_get_methods)(void*, void**);
    void* (*class_get_field_from_name)(void*, const char*);
    void (*field_static_get_value)(void*, void*);
    void (*field_get_value)(void*, void*, void*);
    void (*field_set_value)(void*, void*, void*);
    void* (*runtime_invoke)(void*, void*, void**, void**);
    void* (*string_new)(const char*);
    uint16_t* (*string_chars)(void*);
    int32_t (*string_length)(void*);
    const char* (*method_get_name)(void*);
    uint32_t (*method_get_param_count)(void*);
    void* (*method_get_param)(void*, uint32_t);
    char* (*type_get_name)(void*);
};

Api A{};
bool g_ready = false;
std::mutex g_mu;  // semua panggilan ke IL2CPP diserialkan

struct Classes {
    void* main = nullptr;
    void* player = nullptr;
    void* lang = nullptr;
} C;

#define RESOLVE(name)                                                              \
    A.name = reinterpret_cast<decltype(A.name)>(dlsym(h, "il2cpp_" #name));        \
    if (!A.name) { err = std::string("simbol il2cpp_") + #name + " tidak ada"; return false; }

bool resolve_api(std::string& err) {
    void* h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) { err = "libil2cpp.so belum termuat"; return false; }
    RESOLVE(domain_get)
    RESOLVE(thread_attach)
    RESOLVE(domain_get_assemblies)
    RESOLVE(assembly_get_image)
    RESOLVE(class_from_name)
    RESOLVE(class_get_methods)
    RESOLVE(class_get_field_from_name)
    RESOLVE(field_static_get_value)
    RESOLVE(field_get_value)
    RESOLVE(field_set_value)
    RESOLVE(runtime_invoke)
    RESOLVE(string_new)
    RESOLVE(string_chars)
    RESOLVE(string_length)
    RESOLVE(method_get_name)
    RESOLVE(method_get_param_count)
    RESOLVE(method_get_param)
    RESOLVE(type_get_name)
    return true;
}

void attach() {
    void* d = A.domain_get();
    if (d) A.thread_attach(d);
}

void* find_class(const char* ns, const char* name) {
    void* dom = A.domain_get();
    if (!dom) return nullptr;
    size_t n = 0;
    void** asms = A.domain_get_assemblies(dom, &n);
    for (size_t i = 0; asms && i < n; i++) {
        void* img = A.assembly_get_image(asms[i]);
        if (!img) continue;
        void* k = A.class_from_name(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}

void ensure_classes() {
    if (!C.main) C.main = find_class("Terraria", "Main");
    if (!C.player) C.player = find_class("Terraria", "Player");
    if (!C.lang) C.lang = find_class("Terraria", "Lang");
}

// Cari method berdasarkan nama + jumlah parameter (+ tipe parameter ke-pidx bila perlu).
void* find_method(void* k, const char* name, int argc, int pidx = -1, const char* ptype = nullptr) {
    if (!k) return nullptr;
    void* iter = nullptr;
    void* m;
    while ((m = A.class_get_methods(k, &iter)) != nullptr) {
        if (strcmp(A.method_get_name(m), name) != 0) continue;
        if ((int)A.method_get_param_count(m) != argc) continue;
        if (pidx >= 0 && ptype) {
            char* tn = A.type_get_name(A.method_get_param(m, (uint32_t)pidx));
            if (!tn || strcmp(tn, ptype) != 0) continue;
        }
        return m;
    }
    return nullptr;
}

bool invoke(void* m, void* obj, void** args, void** ret) {
    void* exc = nullptr;
    void* r = A.runtime_invoke(m, obj, args, &exc);
    if (exc) return false;
    if (ret) *ret = r;
    return true;
}

bool static_int(void* klass, const char* field, int& out) {
    void* f = A.class_get_field_from_name(klass, field);
    if (!f) return false;
    A.field_static_get_value(f, &out);
    return true;
}

bool static_bool(void* klass, const char* field, bool& out) {
    void* f = A.class_get_field_from_name(klass, field);
    if (!f) return false;
    uint8_t v = 0;
    A.field_static_get_value(f, &v);
    out = v != 0;
    return true;
}

// Ambil objek Player milik pemain lokal. Mengembalikan nullptr + isi err bila gagal.
void* local_player(std::string& err) {
    ensure_classes();
    if (!C.main) { err = "class Terraria.Main tidak ketemu"; return nullptr; }
    if (!C.player) { err = "class Terraria.Player tidak ketemu"; return nullptr; }

    bool menu = false;
    if (static_bool(C.main, "gameMenu", menu) && menu) {
        err = "masih di menu utama, masuk dulu ke dunia";
        return nullptr;
    }

    if (void* m = find_method(C.main, "get_LocalPlayer", 0)) {
        void* r = nullptr;
        if (invoke(m, nullptr, nullptr, &r) && r) return r;
    }

    void* fp = A.class_get_field_from_name(C.main, "player");
    int idx = -1;
    if (!fp || !static_int(C.main, "myPlayer", idx)) {
        err = "field Main.player / Main.myPlayer tidak ketemu";
        return nullptr;
    }
    void* arr = nullptr;
    A.field_static_get_value(fp, &arr);
    if (!arr || idx < 0 || idx > 255) { err = "pemain belum ada"; return nullptr; }
    // Il2CppArray: header objek (2 pointer) + bounds + max_length, lalu elemen.
    char* base = reinterpret_cast<char*>(arr) + 4 * sizeof(void*);
    void* p = *reinterpret_cast<void**>(base + (size_t)idx * sizeof(void*));
    if (!p) { err = "objek pemain kosong"; return nullptr; }
    return p;
}

bool get_i(void* pl, const char* f, int& v) {
    void* fl = A.class_get_field_from_name(C.player, f);
    if (!fl) return false;
    A.field_get_value(pl, fl, &v);
    return true;
}

bool set_i(void* pl, const char* f, int v) {
    void* fl = A.class_get_field_from_name(C.player, f);
    if (!fl) return false;
    A.field_set_value(pl, fl, &v);
    return true;
}

bool set_b(void* pl, const char* f, bool b) {
    void* fl = A.class_get_field_from_name(C.player, f);
    if (!fl) return false;
    uint8_t v = b ? 1 : 0;
    A.field_set_value(pl, fl, &v);
    return true;
}

const char* yn(bool b) { return b ? "OK" : "TIDAK ADA"; }

std::string give_item(int id, int stack) {
    std::lock_guard<std::mutex> lk(g_mu);
    if (!g_ready) return "Belum siap";
    attach();
    std::string err;
    void* pl = local_player(err);
    if (!pl) return "Gagal: " + err;

    void* qm = find_method(C.player, "QuickSpawnItem", 3, 1, "System.Int32");
    if (!qm) return "Gagal: Player.QuickSpawnItem(source,int,int) tidak ketemu (cek Diagnostik)";

    void* src = nullptr;
    const char* names[] = {"GetSource_Misc", "GetSource_GiftOrReward"};
    for (const char* n : names) {
        void* sm = find_method(C.player, n, 1, 0, "System.String");
        if (!sm) continue;
        void* args[1] = {A.string_new("NurzMenu")};
        void* r = nullptr;
        if (invoke(sm, pl, args, &r) && r) { src = r; break; }
    }
    if (!src) return "Gagal: sumber item (IEntitySource) tidak didapat (cek Diagnostik)";

    int i = id, s = stack;
    void* args[3] = {src, &i, &s};
    if (!invoke(qm, pl, args, nullptr)) return "Gagal: game melempar exception";
    return "OK: item " + std::to_string(id) + " x" + std::to_string(stack) + " diberikan";
}

std::string refill() {
    std::lock_guard<std::mutex> lk(g_mu);
    if (!g_ready) return "Belum siap";
    attach();
    std::string err;
    void* pl = local_player(err);
    if (!pl) return "Gagal: " + err;
    int life = 0, mana = 0;
    bool a = get_i(pl, "statLifeMax2", life) && set_i(pl, "statLife", life);
    bool b = get_i(pl, "statManaMax2", mana) && set_i(pl, "statMana", mana);
    if (!a && !b) return "Gagal: field statLife/statMana tidak ketemu";
    return "OK: HP dan mana diisi penuh";
}

std::atomic<bool> g_god{false};
std::atomic<bool> g_godRunning{false};

void god_loop() {
    {
        std::lock_guard<std::mutex> lk(g_mu);
        attach();
    }
    while (g_god.load()) {
        {
            std::lock_guard<std::mutex> lk(g_mu);
            std::string err;
            void* pl = local_player(err);
            if (pl) {
                int life = 0;
                if (get_i(pl, "statLifeMax2", life)) set_i(pl, "statLife", life);
                set_b(pl, "immune", true);
                set_i(pl, "immuneTime", 10);
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(25));
    }
    g_godRunning.store(false);
}

std::u16string widen(const std::string& s) {
    return std::u16string(s.begin(), s.end());  // hanya dipakai untuk angka ASCII
}

std::u16string load_names() {
    std::lock_guard<std::mutex> lk(g_mu);
    if (!g_ready) return u"";
    attach();
    ensure_classes();
    void* m = find_method(C.lang, "GetItemNameValue", 1, 0, "System.Int32");
    if (!m) return u"";

    int maxId = 0;
    if (C.main) {
        int v = 0;
        if (static_int(C.main, "maxItemTypes", v) && v > 0 && v < 20000) maxId = v;
    }
    if (!maxId) maxId = 6000;

    std::u16string out;
    for (int id = 1; id < maxId; id++) {
        int cid = id;
        void* args[1] = {&cid};
        void* r = nullptr;
        if (!invoke(m, nullptr, args, &r) || !r) continue;
        int len = A.string_length(r);
        if (len <= 0) continue;
        const uint16_t* ch = A.string_chars(r);
        // lewati kunci lokalisasi mentah seperti "ItemName.xxx"
        if (len > 9 && ch[0] == 'I' && ch[1] == 't' && ch[2] == 'e' && ch[3] == 'm' && ch[4] == 'N') continue;
        out += widen(std::to_string(id));
        out += u'|';
        out.append(reinterpret_cast<const char16_t*>(ch), (size_t)len);
        out += u'\n';
    }
    return out;
}

std::string diag() {
    std::lock_guard<std::mutex> lk(g_mu);
    if (!g_ready) return "IL2CPP belum siap";
    attach();
    ensure_classes();
    std::string s;
    s += std::string("Class Main: ") + yn(C.main != nullptr) + "\n";
    s += std::string("Class Player: ") + yn(C.player != nullptr) + "\n";
    s += std::string("Class Lang: ") + yn(C.lang != nullptr) + "\n";
    if (C.main) {
        s += std::string("Main.get_LocalPlayer: ") + yn(find_method(C.main, "get_LocalPlayer", 0) != nullptr) + "\n";
        s += std::string("Main.player: ") + yn(A.class_get_field_from_name(C.main, "player") != nullptr) + "\n";
        s += std::string("Main.myPlayer: ") + yn(A.class_get_field_from_name(C.main, "myPlayer") != nullptr) + "\n";
        s += std::string("Main.gameMenu: ") + yn(A.class_get_field_from_name(C.main, "gameMenu") != nullptr) + "\n";
    }
    if (C.player) {
        s += std::string("QuickSpawnItem(src,int,int): ") + yn(find_method(C.player, "QuickSpawnItem", 3, 1, "System.Int32") != nullptr) + "\n";
        s += std::string("GetSource_Misc(string): ") + yn(find_method(C.player, "GetSource_Misc", 1, 0, "System.String") != nullptr) + "\n";
        const char* fields[] = {"statLife", "statLifeMax2", "statMana", "statManaMax2", "immune", "immuneTime"};
        for (const char* f : fields)
            s += std::string("Player.") + f + ": " + yn(A.class_get_field_from_name(C.player, f) != nullptr) + "\n";
    }
    if (C.lang)
        s += std::string("Lang.GetItemNameValue(int): ") + yn(find_method(C.lang, "GetItemNameValue", 1, 0, "System.Int32") != nullptr) + "\n";
    std::string err;
    void* pl = local_player(err);
    s += pl ? "Pemain lokal: OK" : ("Pemain lokal: " + err);
    return s;
}

jstring js(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }

}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nInit(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lk(g_mu);
    std::string err;
    if (!g_ready) {
        if (!resolve_api(err)) return js(env, err);
    }
    attach();
    ensure_classes();
    if (!C.main || !C.player) return js(env, "menunggu game selesai dimuat (Terraria.Main belum ada)");
    g_ready = true;
    LOG("il2cpp siap");
    return js(env, "OK");
}

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nDiag(JNIEnv* env, jclass) {
    return js(env, diag());
}

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nLoadItemNames(JNIEnv* env, jclass) {
    std::u16string r = load_names();
    return env->NewString(reinterpret_cast<const jchar*>(r.data()), (jsize)r.size());
}

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nGiveItem(JNIEnv* env, jclass, jint id, jint stack) {
    return js(env, give_item(id, stack));
}

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nSetGod(JNIEnv* env, jclass, jboolean on) {
    if (on) {
        g_god.store(true);
        if (!g_godRunning.exchange(true)) std::thread(god_loop).detach();
        return js(env, "God mode ON");
    }
    g_god.store(false);
    return js(env, "God mode OFF");
}

JNIEXPORT jstring JNICALL Java_com_nurz_terrariamenu_NativeBridge_nRefill(JNIEnv* env, jclass) {
    return js(env, refill());
}

}  // extern "C"
