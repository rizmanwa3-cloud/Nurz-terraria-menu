package com.nurz.terrariamenu;

/** Jembatan JNI ke libnurzbridge.so (lihat cpp/il2cpp_bridge.cpp). */
public final class NativeBridge {
    private NativeBridge() {}

    /** Memuat .so dari path absolut. Dipanggil dari class ini supaya terikat ke classloader modul. */
    public static String load(String path) {
        try {
            System.load(path);
            return "OK";
        } catch (Throwable t) {
            return "Gagal memuat library: " + t;
        }
    }

    public static native String nInit();
    public static native String nDiag();
    public static native String nLoadItemNames();
    public static native String nGiveItem(int id, int stack);
    public static native String nSetGod(boolean on);
    public static native String nRefill();
}
