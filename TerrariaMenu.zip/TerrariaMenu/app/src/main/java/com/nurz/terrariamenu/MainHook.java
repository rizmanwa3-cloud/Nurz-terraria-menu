package com.nurz.terrariamenu;

import android.app.Activity;

import java.lang.ref.WeakReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage, IXposedHookZygoteInit {

    private static final String TARGET = "com.and.games505.TerrariaPaid";

    private static String modulePath;
    private static WeakReference<Activity> attachedTo = new WeakReference<>(null);

    @Override
    public void initZygote(StartupParam startupParam) {
        modulePath = startupParam.modulePath;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;

        if (modulePath == null) modulePath = guessModulePath();
        XposedBridge.log("TerrariaMenu: dimuat, modulePath=" + modulePath);

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                final Activity a = (Activity) param.thisObject;
                if (!TARGET.equals(a.getPackageName())) return;
                if (attachedTo.get() == a) return;
                attachedTo = new WeakReference<>(a);
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            new MenuOverlay(a, modulePath).show();
                        } catch (Throwable t) {
                            XposedBridge.log("TerrariaMenu: gagal pasang overlay: " + t);
                        }
                    }
                });
            }
        });
    }

    /** Cadangan bila modulePath tidak diberikan (mis. mode embed LSPatch). */
    private static String guessModulePath() {
        try {
            String s = MainHook.class.getClassLoader().toString();
            Matcher m = Pattern.compile("zip file \"([^\"]+)\"").matcher(s);
            if (m.find()) return m.group(1);
        } catch (Throwable ignored) {
        }
        return null;
    }
}
