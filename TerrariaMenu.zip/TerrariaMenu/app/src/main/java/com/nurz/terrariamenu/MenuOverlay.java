package com.nurz.terrariamenu;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Overlay menu: tombol "N" yang bisa digeser + panel give item / god mode / HP-mana penuh. */
public class MenuOverlay {

    private final Activity act;
    private final String modulePath;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService ex = Executors.newSingleThreadExecutor();

    private final List<Integer> ids = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private int selectedId = -1;
    private String selectedName = "";
    private boolean god = false;

    private TextView status;
    private TextView selectedTv;
    private EditText search;
    private EditText stackEt;
    private LinearLayout resultsBox;
    private ScrollView panel;
    private Button godBtn;

    public MenuOverlay(Activity act, String modulePath) {
        this.act = act;
        this.modulePath = modulePath;
    }

    private int dp(float v) {
        return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f);
    }

    // ------------------------------------------------------------------ UI

    public void show() {
        FrameLayout root = new FrameLayout(act);

        // Tombol melayang
        final TextView btn = new TextView(act);
        btn.setText("N");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(16);
        btn.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xCC6A1B9A);
        btn.setBackground(circle);
        final FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(44), dp(44));
        bp.leftMargin = dp(8);
        bp.topMargin = dp(80);
        btn.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startLeft, startTop;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startLeft = bp.leftMargin;
                        startTop = bp.topMargin;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bp.leftMargin = Math.max(0, (int) (startLeft + dx));
                            bp.topMargin = Math.max(0, (int) (startTop + dy));
                            v.setLayoutParams(bp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                        }
                        return true;
                }
                return false;
            }
        });
        root.addView(btn, bp);

        // Panel
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        panel = new ScrollView(act);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(0xEE1E1E1E);
        pbg.setCornerRadius(dp(10));
        panel.setBackground(pbg);
        panel.setVisibility(View.GONE);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(300), (int) (dm.heightPixels * 0.88f));
        pp.gravity = Gravity.END | Gravity.TOP;
        pp.topMargin = dp(8);
        pp.rightMargin = dp(8);

        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        box.addView(label("nurz terraria menu", 16, Color.WHITE, true));

        status = label("Memulai…", 11, 0xFFB0BEC5, false);
        box.addView(status);

        search = new EditText(act);
        search.setHint("cari item atau ketik ID");
        search.setHintTextColor(0xFF757575);
        search.setTextColor(Color.WHITE);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { refreshResults(); }
        });
        box.addView(search);

        resultsBox = new LinearLayout(act);
        resultsBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(resultsBox);

        selectedTv = label("Dipilih: -", 12, 0xFFFFD54F, false);
        box.addView(selectedTv);

        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label("Jumlah", 12, Color.WHITE, false));
        stackEt = new EditText(act);
        stackEt.setText("1");
        stackEt.setTextColor(Color.WHITE);
        stackEt.setTextSize(14);
        stackEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        stackEt.setSingleLine(true);
        row.addView(stackEt, new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(row);

        box.addView(button("Beri item", new View.OnClickListener() {
            @Override public void onClick(View v) { giveSelected(); }
        }));

        godBtn = button("God mode: OFF", new View.OnClickListener() {
            @Override public void onClick(View v) { toggleGod(); }
        });
        box.addView(godBtn);

        box.addView(button("HP & mana penuh", new View.OnClickListener() {
            @Override public void onClick(View v) {
                run(new Job() { @Override public String call() { return NativeBridge.nRefill(); } });
            }
        }));

        box.addView(button("Diagnostik", new View.OnClickListener() {
            @Override public void onClick(View v) {
                run(new Job() { @Override public String call() { return NativeBridge.nDiag(); } });
            }
        }));

        root.addView(panel, pp);
        act.addContentView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ex.execute(new Runnable() {
            @Override public void run() { boot(); }
        });
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(act);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(act);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void setStatus(final String s) {
        ui.post(new Runnable() {
            @Override public void run() { status.setText(s); }
        });
    }

    // ------------------------------------------------------------------ logika

    private interface Job { String call(); }

    private void run(final Job job) {
        ex.execute(new Runnable() {
            @Override public void run() {
                String r;
                try {
                    r = job.call();
                } catch (Throwable t) {
                    r = "Error: " + t;
                }
                setStatus(r);
            }
        });
    }

    private void giveSelected() {
        if (selectedId < 0) {
            status.setText("Pilih item dulu (cari nama atau ketik ID)");
            return;
        }
        int stack = 1;
        try {
            stack = Integer.parseInt(stackEt.getText().toString().trim());
        } catch (Exception ignored) {
        }
        final int st = Math.max(1, Math.min(9999, stack));
        final int id = selectedId;
        run(new Job() {
            @Override public String call() { return NativeBridge.nGiveItem(id, st); }
        });
    }

    private void toggleGod() {
        god = !god;
        godBtn.setText(god ? "God mode: ON" : "God mode: OFF");
        final boolean on = god;
        run(new Job() {
            @Override public String call() { return NativeBridge.nSetGod(on); }
        });
    }

    private void refreshResults() {
        resultsBox.removeAllViews();
        final String q = search.getText().toString().trim().toLowerCase();
        if (q.isEmpty()) return;

        boolean numeric = q.matches("\\d{1,5}");
        if (numeric) {
            selectedId = Integer.parseInt(q);
            selectedName = "";
            for (int i = 0; i < ids.size(); i++) {
                if (ids.get(i) == selectedId) { selectedName = names.get(i); break; }
            }
            selectedTv.setText("Dipilih: " + (selectedName.isEmpty() ? "" : selectedName + " ") + "(ID " + selectedId + ")");
            return;
        }

        int shown = 0;
        for (int i = 0; i < names.size() && shown < 12; i++) {
            if (!names.get(i).toLowerCase().contains(q)) continue;
            final int id = ids.get(i);
            final String name = names.get(i);
            TextView t = new TextView(act);
            t.setText(name + "  (" + id + ")");
            t.setTextColor(Color.WHITE);
            t.setTextSize(13);
            t.setPadding(dp(6), dp(8), dp(6), dp(8));
            t.setBackgroundColor(0x33FFFFFF);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    selectedId = id;
                    selectedName = name;
                    selectedTv.setText("Dipilih: " + name + " (ID " + id + ")");
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(2);
            resultsBox.addView(t, lp);
            shown++;
        }
        if (shown == 0) {
            TextView t = label("Tidak ada hasil. Ketik ID langsung bila tahu.", 12, 0xFFB0BEC5, false);
            resultsBox.addView(t);
        }
    }

    // ------------------------------------------------------------------ boot (thread latar)

    private void boot() {
        setStatus("Memuat library native…");
        String lib = extractLib();
        if (lib == null) {
            setStatus("Gagal: libnurzbridge.so tidak ditemukan di modul (modulePath=" + modulePath + ")");
            return;
        }
        String r = NativeBridge.load(lib);
        if (!"OK".equals(r)) {
            setStatus(r);
            return;
        }

        String st = "";
        for (int i = 0; i < 60; i++) {
            st = NativeBridge.nInit();
            if ("OK".equals(st)) break;
            setStatus("Menunggu game… " + st);
            try { Thread.sleep(2000); } catch (InterruptedException ignored) { }
        }
        if (!"OK".equals(st)) {
            setStatus("Gagal init IL2CPP: " + st);
            loadFallbackItems();
            return;
        }

        setStatus("Memuat daftar item…");
        String all = NativeBridge.nLoadItemNames();
        final List<Integer> tIds = new ArrayList<>();
        final List<String> tNames = new ArrayList<>();
        if (all != null) {
            for (String line : all.split("\n")) {
                int p = line.indexOf('|');
                if (p <= 0) continue;
                try {
                    tIds.add(Integer.parseInt(line.substring(0, p)));
                    tNames.add(line.substring(p + 1));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        if (tIds.isEmpty()) {
            loadFallbackItems();
            setStatus("Siap, tapi daftar nama dari game kosong. Pakai daftar kecil / ketik ID.");
            return;
        }
        applyItems(tIds, tNames);
        setStatus("Siap. " + tIds.size() + " item dimuat.");
    }

    private void applyItems(final List<Integer> i, final List<String> n) {
        ui.post(new Runnable() {
            @Override public void run() {
                ids.clear();
                names.clear();
                ids.addAll(i);
                names.addAll(n);
            }
        });
    }

    private void loadFallbackItems() {
        try {
            if (modulePath == null) return;
            ZipFile z = new ZipFile(modulePath);
            try {
                ZipEntry e = z.getEntry("assets/items.json");
                if (e == null) return;
                InputStream in = z.getInputStream(e);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                JSONArray arr = new JSONArray(bo.toString("UTF-8"));
                List<Integer> i = new ArrayList<>();
                List<String> nm = new ArrayList<>();
                for (int k = 0; k < arr.length(); k++) {
                    JSONObject o = arr.getJSONObject(k);
                    i.add(o.getInt("id"));
                    nm.add(o.getString("name"));
                }
                applyItems(i, nm);
            } finally {
                z.close();
            }
        } catch (Throwable ignored) {
        }
    }

    /** Salin libnurzbridge.so dari APK modul ke code cache game, lalu kembalikan path-nya. */
    private String extractLib() {
        try {
            if (modulePath == null) return null;
            String abi = android.os.Process.is64Bit() ? "arm64-v8a" : "armeabi-v7a";
            ZipFile z = new ZipFile(modulePath);
            try {
                ZipEntry e = z.getEntry("lib/" + abi + "/libnurzbridge.so");
                if (e == null) return null;
                File out = new File(act.getCodeCacheDir(), "libnurzbridge.so");
                if (out.exists()) {
                    out.setWritable(true);
                    out.delete();
                }
                InputStream in = z.getInputStream(e);
                FileOutputStream os = new FileOutputStream(out);
                try {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    os.close();
                    in.close();
                }
                out.setReadOnly();
                return out.getAbsolutePath();
            } finally {
                z.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }
}
